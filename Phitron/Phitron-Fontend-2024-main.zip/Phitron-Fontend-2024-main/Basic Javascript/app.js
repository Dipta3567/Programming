// var test = "Hello world";

// var num = 10;

// var status = true;

// var obj = {
//   name: "gias",
// };

// console.log(typeof obj);

// var num = "12.5";
// var num1 = 15;

// //converted into number
// var result = parseFloat(num)

// console.log(typeof result);

// var status = "rains";

// if (false) {
//     console.log("brishit hocce tai baire jawa jabe nah");
// }

// else {
//     console.log('baire jawa jabe')
// }

// 0 - 39=c
// 40 - 59=B
// 60 - 69=A-

//     70 - 79=A

//     80-100=A+

// var result = 50;

// if (result < 0) {
//   console.log("failed");
// } else if (result >= 0 && result < 40) {
//   console.log("tumi C grade paico");
// } else if (result >= 40 && result < 60) {
//   console.log("tumi B grade paico");
// } else if (result >= 60 && result < 70) {
//   console.log("tumi A- grade paico");
// } else {
//   console.log("invalid");
// }

// var result = 80;

// var person = {
//     hand: 2,
//     eye: 2,
//     hair: "dont know",
//     father: {
//         name: "jhon",
//         age: 20,
//       },
// }

// console.log(person.father.age);

var test = "Test";

// console.log(friends[4]);

// friends.push("Gias");

// friends.pop()
// friends.unshift("Gias");

// friends.shift();
// console.log(friends);

var friends = [
  "hero",
  5,
  "ALom",
  test,
  { name: "jhon" },
  ["rohim", "korim"],
  "jobbar",
];

// console.log(friends[0])
// console.log(friends[1])
// console.log(friends[2])
// console.log(friends[3])
// console.log(friends[4])
// console.log(friends[5])

// for (var i = 0; i < friends.length; i++) {
//   var element = friends[i];

//   if (element == "ALom") {
//     console.log("yesss sir");
//   } else {
//     console.log("noooo sir");
//     }

// }

// for (var index = 0; index < 20; index++) {
//     var element = index
//     console.log(element);
// }

function sum(num1, num2) {
  var result = num1 + num2;
  console.log(result);
}

sum(20, 30);
