ACCOUNT_TYPE = (
    ('Savings', 'Savings'),
    ('Current', 'Current'),
)
GENDER_TYPE = (
    ('Male', 'Male'),
    ('Female', 'Female'),
)