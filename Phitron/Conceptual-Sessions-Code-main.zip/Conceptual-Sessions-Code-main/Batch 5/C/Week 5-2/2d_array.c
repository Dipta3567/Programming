#include<stdio.h>
int main()
{
    int marks[100][5];
   
    return 0;
}