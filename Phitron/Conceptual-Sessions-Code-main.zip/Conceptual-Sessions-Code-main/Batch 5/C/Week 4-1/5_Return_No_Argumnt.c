/***
 * Example : Phi value
 *  
*/


#include<stdio.h>

float getPHI(void){
    return 3.1416;
}


int main()
{
    float PI = getPHI();    
    printf("%f",PI);       
    return 0;
}
