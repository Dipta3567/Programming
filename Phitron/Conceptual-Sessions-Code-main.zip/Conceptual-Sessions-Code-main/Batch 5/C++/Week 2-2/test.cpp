/*
||-----------------------||
||  Asif Mohammed Sifat  ||
||  Department of CSE    ||
||   CS Instructor       ||
||Phitron,ProgrammingHero||
||-----------------------||
*/

/*
Sample Input: 

I LOVE  STRING

Sample Output:
3


**/


#include <bits/stdc++.h>
using namespace std;
int main()
{
    string s;
    getline(cin,s);

    stringstream ss;

    ss<<s;

    string word;
    int cnt;
    for(cnt=0;ss>>word;cnt++){    
        
    }

    cout<<cnt<<endl;



    return 0;
}