/*
||-----------------------||
||  All Praise to Allah  ||
||-----------------------||
||  Asif Mohammed Sifat  ||
||  Department of CSE    ||
||   CS Instructor       ||
||Phitron,ProgrammingHero||
||-----------------------||
*/
#include<bits/stdc++.h>
using namespace std;
                    
int main(){
    string str = "ProgrammingPhitronHero";

    str.replace(str.find("Phitron"),7," ");
    cout<<str;
              
    return 0;
}
